(function () {
  "use strict";
  window.dataLayer = window.dataLayer || [];
  function track(event, params) {
    window.dataLayer.push(Object.assign({ event: event }, params || {}));
  }

  // Année dynamique dans le footer
  var y = document.getElementById("year");
  if (y) y.textContent = new Date().getFullYear();

  // ---- Conversion : clic-to-call ----
  document.querySelectorAll('[data-cta="phone"]').forEach(function (el) {
    el.addEventListener("click", function () {
      track("click_to_call", { conversion_type: "phone" });
    });
  });

  // ---- Slider avant / après ----
  (function () {
    var input = document.getElementById("ba1-input");
    var before = document.getElementById("ba1-before");
    var handle = document.getElementById("ba1-handle");
    if (!input || !before || !handle) return;
    function setPos(v) {
      before.style.width = v + "%";
      handle.style.left = v + "%";
      handle.setAttribute("aria-valuenow", Math.round(v));
    }
    input.addEventListener("input", function () { setPos(input.value); });
    handle.addEventListener("keydown", function (e) {
      var v = parseInt(input.value, 10);
      if (e.key === "ArrowLeft") { v = Math.max(0, v - 5); }
      else if (e.key === "ArrowRight") { v = Math.min(100, v + 5); }
      else return;
      input.value = v; setPos(v); e.preventDefault();
    });
    setPos(50);
  })();

  // ---- Formulaire devis ----
  var form = document.getElementById("quote-form");
  if (form) {
    var started = false;
    // Conversion : début de saisie
    form.addEventListener("focusin", function () {
      if (!started) { started = true; track("form_start", { form_name: "devis" }); }
    });

    // Libellé du champ photos
    var fileInput = document.getElementById("photos");
    var fileLabel = document.getElementById("upload-label");
    if (fileInput && fileLabel) {
      fileInput.addEventListener("change", function () {
        var n = fileInput.files ? fileInput.files.length : 0;
        fileLabel.textContent = n === 0
          ? "Ajouter des photos de la façade"
          : n + " photo" + (n > 1 ? "s" : "") + " ajoutée" + (n > 1 ? "s" : "");
      });
    }

    var status = document.getElementById("form-status");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      status.className = "form-status";
      status.textContent = "Envoi en cours…";
      var data = new FormData(form);
      fetch(form.action, { method: "POST", body: data })
        .then(function (r) { return r.json().catch(function () { return {}; }); })
        .then(function (res) {
          if (res && res.success) {
            // Conversion principale : lead généré
            track("generate_lead", { form_name: "devis", value: 1, currency: "EUR" });
            status.className = "form-status ok";
            status.textContent = "Merci ! Votre demande est bien partie. Nous vous répondons sous 24h.";
            form.reset();
            if (fileLabel) fileLabel.textContent = "Ajouter des photos de la façade";
          } else {
            throw new Error((res && res.message) || "Erreur");
          }
        })
        .catch(function () {
          status.className = "form-status err";
          status.textContent = "Une erreur est survenue. Appelez-nous au 07 69 88 64 54.";
        });
    });
  }
})();
